import json
import boto3
import os

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(os.environ['TABLE_NAME'])

def handler(event, context):
    http_method = event.get('httpMethod') or event.get('requestContext', {}).get('http', {}).get('method')
    
    headers = {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
    }
    
    try:
        # 1. CREATE / ADD TASK
        if http_method == 'POST':
            body_str = event.get('body') or '{}'
            body = json.loads(body_str)
            
            table.put_item(Item={
                'userId': body['userId'],
                'todoId': body['todoId'],
                'task': body['task']
            })
            
            return {
                "statusCode": 201,
                "headers": headers,
                "body": json.dumps({"message": "Task Created Successfully"})
            }

        # 2. GET ALL TASKS
        elif http_method == 'GET':
            response = table.scan()
            return {
                "statusCode": 200,
                "headers": headers,
                "body": json.dumps(response.get('Items', []))
            }

        # 3. DELETE TASK
        elif http_method == 'DELETE':
            path_params = event.get('pathParameters') or {}
            query_params = event.get('queryStringParameters') or {}
            
            todo_id = path_params.get('id')
            user_id = query_params.get('userId')
            
            if not user_id or not todo_id:
                return {
                    "statusCode": 400,
                    "headers": headers,
                    "body": json.dumps({"error": "userId and todoId are required"})
                }
                
            table.delete_item(
                Key={
                    'userId': user_id,
                    'todoId': todo_id
                }
            )
            
            return {
                "statusCode": 200,
                "headers": headers,
                "body": json.dumps({"message": "Task Deleted Successfully"})
            }

        else:
            return {
                "statusCode": 400,
                "headers": headers,
                "body": json.dumps({"error": f"Unsupported method: {http_method}"})
            }

    except Exception as e:
        return {
            "statusCode": 500,
            "headers": headers,
            "body": json.dumps({"error": str(e)})
        }